let loginU = [
    {
        name: 'kaan',
        password: '123'
    },
    {
        name: 'ali',
        password: '123'
    },
    {
        name: 'polis',
        password: 'imdat'
    },
    {
        name: 'anil',
        password: '123'
    }
]
$(document).ready(function () {

    $("#owl-demo").owlCarousel({

        navigation: true, // Show next and prev buttons
        slideSpeed: 300,
        paginationSpeed: 400,
        singleItem: true,
        navigationText: ["<", ">"],
        autoHeight: false

        // "singleItem:true" is a shortcut for:
        // items : 1, 
        // itemsDesktop : false,
        // itemsDesktopSmall : false,
        // itemsTablet: false,
        // itemsMobile : false

    });

});

let clickDarkTheme = '#darkTheme';
$(clickDarkTheme).click(function () {
    let imgValue = null
    let DarkValue = $(this).attr('value');
    if (DarkValue === 'white') {
        imgValue = true
        $('.Wrapper').addClass('dark')
        $(this).attr('value', 'dark')
        $('.Wrapper').removeClass('white')
    } else if (DarkValue === 'dark') {
        imgValue = false
        $('.Wrapper').addClass('white')
        $(this).attr('value', 'white')
        $('.Wrapper').removeClass('dark')
    }
    logoChange(imgValue);
});

function logoChange(imgValue) {
    if (imgValue) {
        $('.logo_light').attr('src', 'imgs/logo_2.png')
        $('.theme_switch').text('Light')
    } else {
        $('.logo_light').attr('src', 'imgs/logoBox.png')
        $('.theme_switch').text('Dark')
    }
};
/* MODAL */
let modal = document.getElementById("myModal");
let clk = document.getElementById("openModal");
let span = document.getElementsByClassName("close")[0];
let log_inn = document.getElementById("Modal_login");
const modal_content = document.querySelector(".modal-content");

clk.onclick = function () {
    starting_modal();
    let modal_login_btn = document.querySelector(".myButon");
    modal_login_btn.addEventListener("click", login);

    let span = document.getElementsByClassName("close")[0];
    span.onclick = function () {
        modal_clear();
        modal.style.display = "none";
    }
    modal.style.display = "block";
}

window.onclick = function (event) {
    if (event.target == modal) {
        modal_clear();
        modal.style.display = "none";
    }
}
/*-----------------------------------------------------------------*/

function login() {
    let id_ = document.getElementById('inputValue'); // inputun value alincak
    let password_ = document.getElementById("inputPw"); // inputun value alincak

    let id = id_.value.trim();
    let password = password_.value.trim();

    if ((id !== '') && (password !== '')) {
        control = false;
        for (let i = 0; i < loginU.length; i++) {
            if (loginU[i].name === id && loginU[i].password === password) {
                control = true;
                break;
            }
        }
        if (control) {
            succes();
            return false;
        }
        else {
            alert_modal("Yanlış Giriş Yaptınız", "danger")
            id_.value = "";
            password_.value = "";
            return false;
        }
    }
    else {
        alert_modal("Boş Giriş YAPTINIZ", "danger")
    }
}

function succes() {
    alert_modal("Başarıyla giriş yaptınız", "success");
}

function starting_modal() {
    let newHead = null
    let newBody = null
    let newFooter = null

    const list_cont_header = document.createElement("div");
    const list_cont_body = document.createElement("div");
    const list_cont_footer = document.createElement("div");

    list_cont_header.innerHTML = "<div class='modal-header'><span class='close'>&times;</span><h2>Login</h2></div>";
    list_cont_body.innerHTML = "<div class='modal-body'><div class='form-group'><label>Username:</label><input type='text' id='inputValue' name='uname' class='form-control' required='required'></div><div class='form-group'><div class='clearfix'><label>Password:</label><a href='#' class='float-right text-muted'><small>Forgot?</small></a></div><input type='password' id='inputPw' name='psw' class='form-control' required='required'></div></div>";
    list_cont_footer.innerHTML = "<div class='modal-footer'><label class='form-check-label'><input type='checkbox'>Remember me</label><input id='Modal_login' type='submit' class='myButon' value='Login'></div>";

    newHead = list_cont_header;
    newBody = list_cont_body;
    newFooter = list_cont_footer;
    modal_content.appendChild(newHead);
    modal_content.appendChild(newBody);
    modal_content.appendChild(newFooter);
}

function alert_modal(mesaj, clas) {
    modal_clear();
    modal_content.innerHTML = "<h3 class='alert alert-" + clas + " w-100'>" + mesaj + "</h3>"
}
function modal_clear() {
    modal_content.innerHTML = "";
}

/* AJAX PART */

document.addEventListener("DOMContentLoaded",loadMixed);

function loadMixed(){
    const xhr = new XMLHttpRequest();
    xhr.open("GET","jsler/haloo.json",true);

    xhr.onload = function(){
        let list_ajax = document.getElementById("ajax_contents");
        if(this.status == 200){
            const contents_ajax = JSON.parse(this.responseText);
            
            contents_ajax.forEach(function(post){
                list_ajax.innerHTML += `
                <div class="article_card_content">
                <div class="article_card">
                    <div class="img_box"><${post.imaj} alt="img1_"></div>
                    <div class="card_content">
                        <div class="title heading_small">${post.title_json}
                        </div>
                        <div class="content_">${post.content_json}</div>
                        <div class="card_bottom">
                            <div class="left"><${post.kartal_json}><span>${post.span_json}</span><span
                                    class="second_span">${post.second_span_json}</span></div>
                            <div class="right"><i class="fas fa-bolt"></i>25<i
                                    class="far fa-comment-dots"></i>55</div>
                        </div>
                    </div>
                </div>
            </div>`;
            });


        }
    }

    xhr.send();

}
